function trocarRelogioum(){
    document.querySelector('#relogiorosa').style.display = 'block';
    document.querySelector('.main').style.display= 'flex';
    document.querySelector('#relogiopreto').style.display='none';
}

function trocarRelogidois(){
    document.querySelector('#relogiopreto').style.display = 'block';
    document.querySelector('.main').style.display= 'flex';
    document.querySelector('#relogiorosa').style.display='none';
    
}


function trocarRelogiotres(){
    document.querySelector('#relogiorosa').style.display = 'block';
    document.querySelector('.main').style.display= 'flex';
    document.querySelector('#relogiopreto').style.display='none';
}

